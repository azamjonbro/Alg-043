<template >
  <p>{{ $t("hackathon.confirm.info") }}</p>
  <router-view></router-view>
</template>
<script>
export default {
  
}
</script>
<style >
  
</style>